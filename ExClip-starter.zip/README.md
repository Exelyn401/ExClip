# ExClip — starter web app

ExClip adalah starter UI untuk workspace auto-clipping dan motion graphics, menggunakan React, TypeScript, Vite, dan CSS.

## Yang sudah bekerja
- UI berbahasa Indonesia, desain gelap responsif, animasi CSS dan Motion.
- Unggah video lokal dan preview di browser.
- Baca durasi video saat metadata tersedia.
- Pilih 5 konsep style motion graphics.
- Buat segmen contoh berdasarkan durasi untuk menguji UI. **Ini bukan deteksi viral atau analisis AI.**
- Klik segmen untuk memindahkan posisi video.
- Ekspor metadata proyek ke JSON. **Ini bukan render MP4.**
- Link Instagram pembuat: https://www.instagram.com/nazlvyn/
- Konfigurasi deploy Netlify untuk Vite SPA.

## Belum tersedia
- Mengunduh/mengakses video dari URL sosial secara otomatis.
- Transkripsi AI, penilaian viral, scene understanding, dan pemilihan momen otomatis sungguhan.
- Menghasilkan aset gambar yang benar-benar memahami isi video.
- Render dan ekspor MP4 dengan motion graphics.
Fitur tersebut memerlukan integrasi backend/proses video dan/atau model AI. UI tidak berpura-pura fitur itu sudah berjalan.

## Jalankan di komputer atau Chromebook

1. Pasang Node.js versi LTS yang didukung oleh Vite.
2. Unduh ZIP proyek ini lalu ekstrak, atau unggah file-file ke repositori GitHub.
3. Buka terminal di folder proyek.
4. Jalankan:
   ```bash
   npm install
   npm run dev
   ```
5. Buka URL lokal yang ditampilkan Vite (biasanya `http://localhost:5173`).
6. Uji dengan mengunggah video yang ada di perangkat.

## Push ke GitHub

Jika proyek dibuat sebagai folder lokal:
```bash
git init
git add .
git commit -m "Build ExClip starter"
git branch -M main
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```
Ganti `USERNAME/NAMA-REPO` dengan repositori milikmu. Jika file sudah diedit langsung di GitHub, lewati langkah git tersebut.

## Deploy ke Netlify

1. Push proyek ke GitHub.
2. Di Netlify, pilih **Add new site / Import an existing project** lalu pilih repositori GitHub.
3. Build command: `npm run build`
4. Publish directory: `dist`
5. Deploy. File `netlify.toml` juga menyimpan pengaturan ini.
6. Setiap push baru ke branch yang terhubung dapat memicu deploy baru.

## Roadmap untuk fitur AI yang sebenarnya

1. **Sumber video**: gunakan file upload sebagai baseline. Untuk URL sosial, integrasikan API resmi atau sumber yang memang memberi akses; jangan mengakali autentikasi, DRM, atau pembatasan platform.
2. **Transkripsi**: tambahkan backend/worker dengan Whisper atau layanan yang dipilih. Pertimbangkan CPU/RAM, antrean, batas durasi, dan biaya.
3. **Deteksi momen**: analisis transkrip, jeda, pergantian pembicara, struktur cerita, dan konteks. Berikan alasan dan timestamp untuk setiap kandidat.
4. **Konteks visual**: ambil entitas/topik dari transkrip, lalu cari aset berlisensi jelas atau buat diagram SVG yang relevan. Simpan sumber, lisensi, dan atribusi.
5. **Motion graphics**: simpan style sebagai konfigurasi layer/timeline yang dapat diedit pengguna.
6. **Render**: lakukan render video di worker yang cocok untuk tugas panjang; jangan mengandalkan Netlify Functions untuk render video berat atau job yang berjalan lama.
7. **Ekspor**: validasi audio, durasi, rasio, codec, dan hasil render sebelum menyatakan berhasil.

## Keamanan
- Jangan menaruh API secret dalam kode frontend atau variabel `VITE_*`.
- Jangan mengklaim layanan gratis tanpa batas; periksa kuota, batas runtime, dan lisensi model/dependensi.
- Tampilkan status fitur yang jujur dan berikan fallback jika layanan AI tidak tersedia.
