import { useEffect, useRef, useState, type ChangeEvent } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import {
  Activity, ArrowDownRight, ArrowRight, AudioLines, Check, ChevronDown,
  CircleHelp, Clapperboard, Clock3, Download, FileVideo2, Film, Gauge,
  Layers3, Link2, LoaderCircle, Play, Plus, Scan, Settings2, Sparkles,
  Upload, WandSparkles, X
} from 'lucide-react'

type StyleId = 'collage' | 'kinetic' | 'documentary' | 'science' | 'cinematic'
type Clip = { id: number; title: string; start: number; end: number; reason: string; score: number }
const styles: { id: StyleId; name: string; description: string; tag: string }[] = [
  { id: 'collage', name: 'Adaptive Collage', description: 'Visual, gambar, dan tipografi mengikuti topik video.', tag: 'Direkomendasikan' },
  { id: 'kinetic', name: 'Kinetic Typography', description: 'Teks ekspresif dengan ritme dan penekanan dinamis.', tag: 'Enerjik' },
  { id: 'documentary', name: 'Documentary Motion', description: 'Foto, label, garis penunjuk, dan layout editorial.', tag: 'Editorial' },
  { id: 'science', name: 'Scientific Explainer', description: 'Diagram dan anotasi untuk menjelaskan konsep.', tag: 'Edukasi' },
  { id: 'cinematic', name: 'Cinematic Minimal', description: 'Ruang kosong, transisi lembut, dan nuansa sinematik.', tag: 'Minimal' },
]
const formatTime = (s: number) => `${Math.floor(s / 60).toString().padStart(2, '0')}:${Math.floor(s % 60).toString().padStart(2, '0')}`
const sourceName = (url: string) => /youtube\.com|youtu\.be/i.test(url) ? 'YouTube' : /instagram\.com/i.test(url) ? 'Instagram' : /tiktok\.com/i.test(url) ? 'TikTok' : 'Sumber video'

export default function App() {
  const [sourceUrl, setSourceUrl] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [videoUrl, setVideoUrl] = useState('')
  const [duration, setDuration] = useState(0)
  const [selectedStyle, setSelectedStyle] = useState<StyleId>('collage')
  const [clips, setClips] = useState<Clip[]>([])
  const [activeClip, setActiveClip] = useState<number | null>(null)
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [showStyles, setShowStyles] = useState(true)
  const [projectName, setProjectName] = useState('Proyek tanpa judul')
  const inputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => () => { if (videoUrl.startsWith('blob:')) URL.revokeObjectURL(videoUrl) }, [videoUrl])

  const handleFile = (e: ChangeEvent<HTMLInputElement>) => {
    const next = e.target.files?.[0]
    if (!next) return
    if (!next.type.startsWith('video/')) { setNotice('Pilih file video dengan format yang didukung browser.'); return }
    if (videoUrl.startsWith('blob:')) URL.revokeObjectURL(videoUrl)
    const localUrl = URL.createObjectURL(next)
    setFile(next); setVideoUrl(localUrl); setClips([]); setActiveClip(null)
    setProjectName(next.name.replace(/\.[^.]+$/, ''))
    setNotice('Video lokal siap dipratinjau. Analisis momen AI belum aktif pada versi awal ini.')
  }

  const analyzeLocal = () => {
    if (!file || !duration) {
      setNotice('Unggah video lokal terlebih dahulu dan tunggu durasinya terbaca.')
      return
    }
    setBusy(true); setNotice('')
    // Placeholder transparan: membagi durasi untuk membantu uji antarmuka, bukan AI viral detection.
    window.setTimeout(() => {
      const count = Math.min(5, Math.max(1, Math.floor(duration / 22)))
      const generated: Clip[] = Array.from({ length: count }, (_, i) => {
        const segment = duration / count
        const start = Math.max(0, Math.floor(i * segment + segment * 0.12))
        const end = Math.min(Math.floor(duration), Math.max(start + 1, Math.floor(start + Math.min(35, segment * 0.72))))
        return { id: i + 1, title: ['Pembuka yang menarik', 'Inti pembahasan', 'Momen untuk ditekankan', 'Bagian informatif', 'Penutup'][i] || `Segmen ${i + 1}`, start, end, reason: 'Segmen contoh berdasarkan pembagian durasi; bukan prediksi viral dari AI.', score: 0 }
      })
      setClips(generated); setActiveClip(generated[0]?.id ?? null); setBusy(false)
      setNotice('Segmen contoh dibuat untuk menguji alur kerja. Deteksi momen viral sungguhan memerlukan backend transkripsi dan analisis.')
    }, 650)
  }

  const openClip = (clip: Clip) => {
    setActiveClip(clip.id)
    if (videoRef.current) { videoRef.current.currentTime = clip.start; videoRef.current.play().catch(() => {}) }
  }

  const exportProject = () => {
    const payload = {
      product: 'ExClip', projectName, source: file ? { type: 'local-file', name: file.name, size: file.size } : sourceUrl ? { type: 'url', url: sourceUrl } : null,
      style: selectedStyle, clips, note: 'Project metadata only. This JSON is not a rendered video export.'
    }
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'exclip-project.json'; a.click(); URL.revokeObjectURL(a.href)
    setNotice('Metadata proyek diunduh sebagai JSON. Ini belum berupa file video hasil render.')
  }

  const handleUrl = () => {
    if (!sourceUrl.trim()) { setNotice('Masukkan link video terlebih dahulu.'); return }
    try {
      const u = new URL(sourceUrl.trim())
      if (!['http:', 'https:'].includes(u.protocol)) throw new Error()
      if (!/youtube\.com|youtu\.be|instagram\.com|tiktok\.com/i.test(u.hostname)) {
        setNotice('Masukkan URL YouTube, Instagram, atau TikTok yang valid.'); return
      }
      setNotice(`Link ${sourceName(sourceUrl)} dikenali. Mengambil video dan menganalisisnya belum aktif: integrasikan backend resmi/berizin terlebih dahulu, atau unggah file video lokal.`)
    } catch { setNotice('Format URL tidak valid. Gunakan link lengkap yang diawali https://.') }
  }

  const active = clips.find(c => c.id === activeClip)
  const currentStyle = styles.find(s => s.id === selectedStyle)!
  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <a className="brand" href="#" aria-label="ExClip beranda"><span className="brand-mark"><Clapperboard size={20}/></span><span>Ex<span className="brand-light">Clip</span></span></a>
        <nav className="topnav"><a href="#workspace">Workspace</a><a href="#styles">Gaya editing</a><a href="#about">Tentang</a></nav>
        <div className="top-actions"><span className="status-pill"><span className="status-dot"/> Versi awal</span><button className="icon-btn" title="Bantuan" onClick={() => setNotice('Versi awal ExClip: impor file lokal, pilih style, uji segmen contoh, dan ekspor metadata proyek.')}><CircleHelp size={18}/></button></div>
      </header>

      <main>
        <section className="hero">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6 }} className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-line"/><span>AI VIDEO WORKSPACE</span></div>
            <h1>Dari video panjang,<br/><span className="gradient-text">jadi momen yang berarti.</span></h1>
            <p>Temukan potensi klip dan rancang motion graphics yang mengikuti isi cerita. Semua dimulai dari satu workspace.</p>
            <a className="hero-link" href="#workspace">Mulai membuat <ArrowDownRight size={17}/></a>
          </motion.div>
          <motion.div className="hero-art" initial={{ opacity: 0, scale: .96 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .7, delay: .12 }}>
            <div className="art-grid"/>
            <div className="art-card art-back"><div className="art-mini-label">VISUAL SYSTEM / 03</div><div className="art-orbit"><span/><span/><span/></div><div className="art-lines"><i/><i/><i/></div></div>
            <div className="art-card art-front"><div className="art-topline"><span>EXCLIP / MOTION ENGINE</span><span className="live-dot"/></div><div className="art-big-type">IDEAS<br/><em>IN MOTION.</em></div><div className="art-bottom"><span>CONTENT-AWARE DESIGN</span><span>00:24 — 00:58</span></div><div className="art-wave">{Array.from({length: 34},(_,i)=><i key={i} style={{height:`${12 + Math.abs(Math.sin(i*.72))*70}%`}}/>)}</div></div>
            <div className="floating-chip chip-one"><Sparkles size={14}/> Content-aware visuals</div><div className="floating-chip chip-two"><Activity size={14}/> Motion synced to story</div>
          </motion.div>
        </section>

        <section className="workspace-section" id="workspace">
          <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> WORKSPACE</div><h2>Mulai proyek baru</h2><p>Masukkan sumber video, tentukan gaya, lalu siapkan konsep klip.</p></div><span className="workspace-tag"><Layers3 size={15}/> Workspace 01</span></div>
          <div className="workspace-grid">
            <div className="panel source-panel">
              <div className="panel-heading"><div className="step-number">01</div><div><h3>Sumber video</h3><p>Gunakan link atau unggah file dari perangkatmu.</p></div></div>
              <label className="field-label" htmlFor="source-url">Link video</label>
              <div className="url-input"><Link2 size={17}/><input id="source-url" value={sourceUrl} onChange={e=>setSourceUrl(e.target.value)} placeholder="Tempel link YouTube, Instagram, TikTok..." /><button onClick={handleUrl} aria-label="Periksa link"><ArrowRight size={17}/></button></div>
              <div className="or-divider"><span>atau unggah file</span></div>
              <button className="upload-zone" onClick={()=>inputRef.current?.click()}>
                <span className="upload-icon"><Upload size={20}/></span><strong>{file ? file.name : 'Pilih video dari perangkat'}</strong><span>{file ? `${(file.size / (1024*1024)).toFixed(1)} MB · file lokal` : 'MP4, WebM, atau format video yang didukung browser'}</span><span className="browse-link">{file ? 'Ganti video' : 'Jelajahi file'} <ArrowRight size={14}/></span>
              </button>
              <input ref={inputRef} type="file" accept="video/*" hidden onChange={handleFile}/>
              <div className="source-footnote"><CircleHelp size={14}/><span>Link sosial belum diunduh otomatis pada versi ini. Gunakan file yang kamu miliki atau berhak memproses.</span></div>
              <div className="field-divider"/>
              <label className="field-label" htmlFor="project-name">Nama proyek</label><input className="text-input" id="project-name" value={projectName} onChange={e=>setProjectName(e.target.value)} placeholder="Misalnya: Video edukasi 01"/>
              <button className="primary-btn full-btn" onClick={analyzeLocal} disabled={busy || !file}>{busy ? <><LoaderCircle className="spin" size={17}/> Menyiapkan segmen...</> : <><WandSparkles size={17}/> Buat segmen contoh <ArrowRight size={16}/></>}</button>
              <p className="button-note">Analisis pada versi awal adalah segmen contoh, bukan deteksi viral berbasis AI.</p>
            </div>

            <div className="panel preview-panel">
              <div className="preview-header"><div className="panel-heading compact"><div className="step-number">02</div><div><h3>Pratinjau & style</h3><p>Visual akan berubah mengikuti pilihan gaya.</p></div></div><button className="subtle-btn" onClick={()=>setShowStyles(!showStyles)}><Settings2 size={15}/> {showStyles ? 'Sembunyikan style' : 'Pilih style'} <ChevronDown size={14}/></button></div>
              <div className={`video-stage style-${selectedStyle}`}>
                {videoUrl ? <video ref={videoRef} src={videoUrl} controls onLoadedMetadata={e=>setDuration(e.currentTarget.duration || 0)} /> : <div className="stage-placeholder"><div className="placeholder-art"><div className="placeholder-ring ring-a"/><div className="placeholder-ring ring-b"/><div className="placeholder-center"><Film size={28}/></div><div className="placeholder-cross cross-a"/><div className="placeholder-cross cross-b"/></div><span>PRATINJAU MOTION GRAPHICS</span><strong>Konten bertemu kreativitas.</strong><small>Unggah video untuk melihat pratinjau sumber.</small></div>}
                <div className="motion-overlay overlay-label"><span className="overlay-kicker">{currentStyle.name.toUpperCase()}</span><strong>{selectedStyle === 'science' ? 'THE SCIENCE' : selectedStyle === 'kinetic' ? 'MAKE IT MOVE' : selectedStyle === 'documentary' ? 'FIELD NOTES / 01' : selectedStyle === 'cinematic' ? 'A NEW PERSPECTIVE' : 'IDEAS IN MOTION'}</strong><span className="overlay-caption">VISUAL DIRECTION / EXCLIP</span></div>
                <div className="stage-index">EX / 001</div>
              </div>
              <div className="preview-meta"><div><span className="meta-label">SUMBER</span><strong>{file ? 'File lokal' : 'Belum ada video'}</strong></div><div><span className="meta-label">DURASI</span><strong>{duration ? `${formatTime(duration)} menit` : '—'}</strong></div><div><span className="meta-label">FORMAT</span><strong>9:16 / Vertical</strong></div></div>
              {showStyles && <div className="style-picker" id="styles"><div className="style-picker-heading"><span>GAYA MOTION GRAPHICS</span><span>{styles.length} gaya</span></div><div className="style-list">{styles.map((s,i)=><button key={s.id} className={`style-option ${selectedStyle===s.id?'selected':''}`} onClick={()=>setSelectedStyle(s.id)}><span className={`style-thumb thumb-${s.id}`}><span className="thumb-line"/><span className="thumb-block"/><span className="thumb-dot"/></span><span className="style-copy"><strong>{s.name}</strong><small>{s.description}</small></span><span className="style-tag">{s.tag}</span>{selectedStyle===s.id && <Check size={16} className="selected-check"/>}</button>)}</div></div>}
            </div>
          </div>
          <AnimatePresence>{notice && <motion.div className="notice" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-6}}><CircleHelp size={17}/><span>{notice}</span><button onClick={()=>setNotice('')} aria-label="Tutup pesan"><X size={15}/></button></motion.div>}</AnimatePresence>
        </section>

        <section className="clips-section">
          <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> CLIP LAB</div><h2>Ruang klip</h2><p>Segmen yang tersedia dari proyek ini akan muncul di sini.</p></div><button className="outline-btn" onClick={exportProject}><Download size={16}/> Ekspor metadata <ArrowRight size={15}/></button></div>
          {clips.length ? <div className="clips-grid">{clips.map((clip,i)=><motion.button key={clip.id} className={`clip-card ${activeClip===clip.id?'clip-active':''}`} onClick={()=>openClip(clip)} initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:i*.06}}><div className="clip-thumb"><div className={`clip-thumb-art thumb-${selectedStyle}`}><span>{String(clip.id).padStart(2,'0')}</span><div className="clip-art-title">{clip.title}</div><div className="clip-art-bars"><i/><i/><i/><i/><i/></div></div><span className="clip-duration">{formatTime(clip.end-clip.start)}</span><span className="clip-play"><Play size={15} fill="currentColor"/></span></div><div className="clip-card-body"><div className="clip-card-title"><strong>{clip.title}</strong><span>{formatTime(clip.start)} – {formatTime(clip.end)}</span></div><p>{clip.reason}</p><div className="clip-card-foot"><span><Scan size={13}/> Segmen contoh</span><span>#{String(clip.id).padStart(2,'0')}</span></div></div></motion.button>)}</div> : <div className="empty-clips"><div className="empty-icon"><FileVideo2 size={24}/></div><strong>Belum ada segmen</strong><span>Unggah video lokal, lalu buat segmen contoh untuk menguji alur kerja.</span></div>}
          {clips.length>0 && <div className="timeline-panel"><div className="timeline-head"><div><h3><AudioLines size={17}/> Timeline proyek</h3><p>Representasi segmen untuk membantu alur editing.</p></div><span className="timeline-total"><Clock3 size={14}/>{formatTime(duration)}</span></div><div className="timeline-ruler"><span>00:00</span><span>{formatTime(duration/2)}</span><span>{formatTime(duration)}</span></div><div className="timeline-track">{clips.map(c=><button key={c.id} onClick={()=>openClip(c)} className={`timeline-segment ${activeClip===c.id?'segment-active':''}`} style={{left:`${duration ? c.start/duration*100 : 0}%`,width:`${duration ? (c.end-c.start)/duration*100 : 0}%`}} title={c.title}><span>{c.title}</span></button>)}</div><div className="timeline-footer"><span><span className="tiny-dot"/> Segmen terpilih</span><span>Style aktif: {currentStyle.name}</span></div></div>}
        </section>

        <section className="how-section"><div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> ALUR KERJA</div><h2>Dirancang untuk bergerak lebih cepat.</h2></div></div><div className="how-grid">{[{n:'01',icon:Link2,title:'Masukkan sumber',desc:'Mulai dari file lokal atau link sumber yang bisa diproses secara sah.'},{n:'02',icon:Gauge,title:'Temukan momen',desc:'Sistem analisis akan mencari bagian yang menarik berdasarkan konteks dan transkrip.'},{n:'03',icon:Layers3,title:'Bangun visual',desc:'Pilih style, sesuaikan aset, tipografi, dan ritme motion graphics.'}].map((item,i)=><motion.div className="how-card" key={item.n} initial={{opacity:0,y:14}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.3}} transition={{delay:i*.08}}><div className="how-card-top"><span>{item.n}</span><item.icon size={20}/></div><h3>{item.title}</h3><p>{item.desc}</p><div className="how-card-line"/></motion.div>)}</div></section>

        <section className="about-section" id="about"><div className="about-mark"><Clapperboard size={24}/></div><div><div className="eyebrow"><span className="eyebrow-line"/> DIBANGUN OLEH</div><h2>Exelyn<span>.</span></h2><p>ExClip adalah proyek untuk membuat proses mengolah video menjadi lebih kreatif, terarah, dan mudah diakses.</p></div><a className="instagram-link" href="https://www.instagram.com/nazlvyn/" target="_blank" rel="noreferrer">Ikuti perjalanan proyek <ArrowRight size={16}/></a></section>
      </main>
      <footer className="footer"><a className="brand footer-brand" href="#"><span className="brand-mark"><Clapperboard size={17}/></span><span>Ex<span className="brand-light">Clip</span></span></a><span>© {new Date().getFullYear()} ExClip. Dibangun oleh Exelyn.</span><a href="https://www.instagram.com/nazlvyn/" target="_blank" rel="noreferrer">Instagram <ArrowDownRight size={13}/></a></footer>
    </div>
  )
}
